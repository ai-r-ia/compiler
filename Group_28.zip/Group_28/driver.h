/*
Group Number: 28
1. Anishka Singh 2020B3A70816P
2. Gautam Jajoo 2020B3A71638P
3. Suraj Phalod 2020B3A71959P
4. Ria Shekhawat 2020B4A71986P
5. Karan Agrawal 2020B4A70830P
*/
#ifndef DRIVER
#define DRIVER

#include "rulesDef.h"
// Function to measure execution time
void measure_execution_time(char *filename, char *treefile, Grammar grammar);

// driver function to allow users to perform an execution of their choice
void driver(char *filename, char *treefile, Grammar grammar);

void lexical_analysis(char *filename);
#endif