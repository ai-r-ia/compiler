# Compiler Project - CS F363

## Group Number: 28
1. Anishka Singh 2020B3A70816P
2. Gautam Jajoo 2020B3A71638P
3. Suraj Phalod 2020B3A71959P
4. Ria Shekhawat 2020B4A71986P
5. Karan Agrawal 2020B4A70830P

## How to run?
copy and paste the following commands on your terminal.
- make
- stage1exe  testcase.txt  parsetreeOutFile.txt
use 'make' command to build the execution file.
The command line argument for execution of the driver should be as follows, for example
where stage1exe is the executable file generated after linking all the files. The file testcase.txt is the sourcecode file in the given language to be analyzed and parsetreeOutFile.txt is the file containing parse tree printed as per the format specified earlier.

## 
 We've added some testcases each of which can be tested by just changing the command line argument. 'filename' in the following command can be replaced by testcase'x' where x can be 1,2,3,4,5,6.
- stage1exe  filename.txt  parsetreeOutFile.txt